from .slic import slic  # noqa
