def raise_if_zero(arg):
    if not arg:
        raise IndexError("arg wasn't there")