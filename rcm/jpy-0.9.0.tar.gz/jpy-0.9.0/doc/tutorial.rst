########
Tutorial
########


Sorry, the jpy tutorial is not yet written. Meanwhile please refer to jpy's Python and Java unit-level tests
in order to learn how to use jpy. They are located at

* `src/test/python <https://github.com/bcdev/jpy/tree/master/src/test/python>`_
* `src/test/java <https://github.com/bcdev/jpy/tree/master/src/test/java>`_


*********************
Using jpy with Python
*********************

Using the Java Standard Library
===============================


Calling your Java Classes from Python
=====================================


Primitive array parameters that are mutable
-------------------------------------------


Primitive array parameters that are return value
------------------------------------------------



*******************
Using jpy with Java
*******************


Getting Started
===============


Using the Python Standard Library
=================================


Calling your Python functions from Java
=======================================


Extending Java with Python
==========================
